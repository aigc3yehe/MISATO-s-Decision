const Menu = () => {
    return (
        <div className="flex items-center">
            <ul className="menu bg-base-200 w-56 rounded-box">
                <li><a>MISATO</a></li>
            </ul>
        </div>
    )
}

export default Menu